package com.ardian.tugas9layoutmovie

data class Data(
    var name: String,
    var detail: String,
    var poster: Int
)